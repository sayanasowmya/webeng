<!DOCTYPE HTML>
<html>
<head>
      
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
          
</head>
<body>
  
    <div class="container">
   
        <div class="page-header">
            <h1>Create Availability</h1>
        </div>
      
	<?php
if($_POST){
 
    include 'config/database.php';
 
    try{
     
        $query = "INSERT INTO product SET suburb=:suburb, postcode=:postcode, address=:address, date=:date, startTime=:startTime, endTime=:endTime, pay=:pay";
        $stmt = $con->prepare($query);
 
        
        $suburb=htmlspecialchars(strip_tags($_POST['suburb']));
        $postcode=htmlspecialchars(strip_tags($_POST['postcode']));
        $address=htmlspecialchars(strip_tags($_POST['address']));
		 $date=htmlspecialchars(strip_tags($_POST['date']));
        $startTime=htmlspecialchars(strip_tags($_POST['startTime']));
        $endTime=htmlspecialchars(strip_tags($_POST['endTime']));
		$pay=htmlspecialchars(strip_tags($_POST['pay']));
 
        
        $stmt->bindParam(':suburb', $suburb);
        $stmt->bindParam(':postcode', $postcode);
        $stmt->bindParam(':address', $address);
		$stmt->bindParam(':date', $date);
        $stmt->bindParam(':startTime', $startTime);
        $stmt->bindParam(':endTime', $endTime);
		 $stmt->bindParam(':pay', $pay);
         
     
         
       
        if($stmt->execute()){
            echo "<div class='alert alert-success'>Record was saved.</div>";
        }else{
            echo "<div class='alert alert-danger'>Unable to save record.</div>";
        }
         
    }
    
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
 ?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>Suburb</td>
            <td><input type='text' name='suburb' class='form-control' /></td>
        </tr>
        <tr>
            <td>Post Code</td>
            <td><input type='text' name='postcode' class='form-control' /></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><input type='text' name='address' class='form-control' /></td>
        </tr>
		<tr>
            <td>Date</td>
            <td><input type='date' name='date' class='form-control' /></td>
        </tr>
        <tr>
            <td>Start Time</td>
            <td><input type='time' name='startTime' class='form-control' /></td>
        </tr>
        <tr>
            <td>End Time</td>
            <td><input type='time' name='endTime' class='form-control' /></td>
        </tr>
		 <tr>
            <td>Pay</td>
            <td><input type='text' name='pay' class='form-control' /></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Save' class='btn btn-primary' />
                <a href='index.php' class='btn btn-danger'>Back</a>
            </td>
        </tr>
    </table>
</form>
          
    </div> <!-- end .container -->
      
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</body>
</html>