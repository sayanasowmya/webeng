<!DOCTYPE HTML>
<html>
<head>
     <link href='assets/css/fullcalendar.css' rel='stylesheet' />
      <link href='assets/css/fullcalendar.print.css' rel='stylesheet' media='print' />
      <script src='assets/js/jquery-1.10.2.js' type="text/javascript"></script>
      <script src='assets/js/jquery-ui.custom.min.js' type="text/javascript"></script>
      <script src='assets/js/fullcalendar.js' type="text/javascript"></script>
	  <script src='calender.css' rel='stylesheet'></script>
	  
     <script> 
		$(function(){
		  $("#header").load("header.html"); 
		 $("#footer").load("footer.html"); 
		});
</script>    
    
  
</head>
<body>
<nav class="navbar navbar-inverse ">
   	<a class="navbar-brand" href="#">
    <img src="lm.png" alt="logo" style="width:40px;">
     </a>
     
      <div class="container-fluid">
         <ul class="nav navbar-nav navbar-right">
            <li id="home" class="navbar-li"><a href="home.html"><span class="glyphicon glyphicon-home"></span> Home</a></li>
            <li class="active navbar-li" id="mybooking"><a href="index.php" ><span class="glyphicon glyphicon-calendar"></span> My Bookings</a></li>
            <li id="myprofile" class="navbar-li"><a href="#" ><span class="glyphicon glyphicon-user"></span> My Profile</a></li>
            <li id="messages" class="navbar-li"><a href="#" ><span class="glyphicon glyphicon-envelope"></span> Messages</a></li>
            <li id="logout" class="navbar-li"><a href="#" ><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
         </ul>
         <ul class="nav navbar-nav navbar-left">
            <li><a href="#"> </a></li>
         </ul>
      </div>
   </nav>
  <div id="header"></div>
    <div class="container">
  
            <h1>Time Sheet </h1>
     
        
        <?php
include 'config/database.php';
 

$query = "SELECT suburb, date, startTime, endTime, pay FROM residentavailability";
$stmt = $con->prepare($query);
$stmt->execute();
 
$num = $stmt->rowCount();
 

 
if($num>0){
 
    echo "<table class='table table-hover table-responsive table-bordered' >";//start table
 

    echo "<tr style='background-color: #C0C0C0;'>";
        echo "<th>Suburb</th>";
        echo "<th>Date</th>";
        echo "<th>Start Time</th>"; 
        echo "<th>End Time</th>";
        echo "<th>Pay</th>";
		echo "<th> </th>";
    echo "</tr>";
     
   
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    
    extract($row);
     
    echo "<tr style='background-color: #9ACD32;'>";
        echo "<td>{$suburb}</td>";
        echo "<td>{$date}</td>";
        echo "<td>{$startTime}</td>";
        echo "<td>{$endTime}</td>";
        echo "<td>&#36;{$pay}/hr</td>";
        echo "<td>";
             
            echo "<a href='read_one.php?id={$suburb}' class='btn btn-info m-r-1em'>Details</a>";
             
            
            echo "<a href='update.php?id={$suburb}' class='btn btn-primary m-r-1em'>Edit</a>";
 
            
            echo "<a href='#' onclick='delete_user({$suburb});'  class='btn btn-danger'>Delete</a>";
        echo "</td>";
    echo "</tr>";
} 

echo "</table>";
}
else{
    echo "<div class='alert alert-danger'>No records found.</div>";
}

echo "<a href='home.html' class='btn btn-primary m-b-1em'>Back</a>";
?>
    </div> 

 <div id="footer"></div>
</body>
</html>